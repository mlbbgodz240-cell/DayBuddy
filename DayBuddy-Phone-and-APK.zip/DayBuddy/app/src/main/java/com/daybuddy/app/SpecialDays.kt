package com.daybuddy.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

data class Celebration(val month: Int, val day: Int, val title: String, val emoji: String, val note: String)
data class DayItem(val date: LocalDate, val title: String, val emoji: String, val note: String, val personal: Boolean = false)

object SpecialDays {
    // A curated calendar of commonly observed dates. Some internet/social-media days vary by source or country.
    val days = listOf(
        Celebration(1, 1, "New Year's Day", "🎆", "A fresh start and a little hope."),
        Celebration(1, 13, "Lohri", "🔥", "Celebrate warmth, harvest and togetherness."),
        Celebration(1, 14, "Makar Sankranti", "🪁", "A harvest festival celebrated in many parts of India."),
        Celebration(1, 26, "Republic Day (India)", "🇮🇳", "Celebrate the Constitution of India."),
        Celebration(2, 7, "Rose Day", "🌹", "A sweet start to Valentine's week."),
        Celebration(2, 8, "Propose Day", "💌", "A day for honest feelings and brave words."),
        Celebration(2, 9, "Chocolate Day", "🍫", "Share something sweet with someone you love."),
        Celebration(2, 10, "Teddy Day", "🧸", "Send a tiny comfort hug."),
        Celebration(2, 11, "Promise Day", "🤝", "Make a promise you truly mean."),
        Celebration(2, 12, "Hug Day", "🫂", "Give someone a little extra warmth."),
        Celebration(2, 13, "Kiss Day", "💋", "A Valentine's week celebration."),
        Celebration(2, 14, "Valentine's Day", "❤️", "Celebrate love in all its forms."),
        Celebration(3, 8, "International Women's Day", "💜", "Celebrate women's achievements."),
        Celebration(3, 14, "Pi Day", "🥧", "A fun day for maths and pie."),
        Celebration(4, 1, "April Fools' Day", "🤡", "Keep the pranks kind."),
        Celebration(4, 22, "Earth Day", "🌍", "Do one small thing for our planet."),
        Celebration(5, 1, "International Workers' Day", "🌱", "Recognize workers and their contributions."),
        Celebration(5, 11, "National Technology Day (India)", "🚀", "Celebrate science and innovation."),
        Celebration(6, 5, "World Environment Day", "🌿", "Give the planet a little love."),
        Celebration(6, 8, "Best Friends Day", "🫶", "Text your person and remind them they matter."),
        Celebration(6, 8, "World Oceans Day", "🌊", "Think blue and protect our oceans."),
        Celebration(7, 30, "International Friendship Day", "🫶", "Celebrate the people who make life brighter."),
        Celebration(8, 15, "Independence Day (India)", "🇮🇳", "Celebrate India's independence."),
        Celebration(9, 5, "Teachers' Day (India)", "📚", "Thank a teacher who helped you grow."),
        Celebration(9, 21, "International Day of Peace", "🕊️", "Choose kindness and understanding."),
        Celebration(10, 14, "World Standards Day", "✨", "A day recognizing the role of standards."),
        Celebration(10, 31, "Halloween", "🎃", "Costumes, spooky vibes and sweet treats."),
        Celebration(11, 14, "Children's Day (India)", "🧸", "Celebrate childhood and young people."),
        Celebration(11, 14, "World Diabetes Day", "💙", "Raise awareness about diabetes."),
        Celebration(11, 19, "International Men's Day", "💙", "Encourage wellbeing and positive role models."),
        Celebration(12, 10, "Human Rights Day", "🕊️", "Remember dignity and rights for everyone."),
        Celebration(12, 25, "Christmas Day", "🎄", "Share joy, peace and kindness."),
        Celebration(12, 31, "New Year's Eve", "🥂", "Look back on the year and look forward.")
    )

    fun itemsFor(date: LocalDate, custom: List<DayItem>): List<DayItem> {
        val official = days.filter { it.month == date.monthValue && it.day == date.dayOfMonth }
            .map { DayItem(date, it.title, it.emoji, it.note) }
        val personal = custom.filter { it.date.monthValue == date.monthValue && it.date.dayOfMonth == date.dayOfMonth }
            .map { it.copy(date = date) }
        return official + personal
    }

    fun upcoming(from: LocalDate, custom: List<DayItem>, limit: Int = 14): List<DayItem> {
        val result = mutableListOf<DayItem>()
        for (offset in 0..365) {
            val date = from.plusDays(offset.toLong())
            result += itemsFor(date, custom)
            if (result.size >= limit) break
        }
        return result.take(limit)
    }

    fun dateLabel(date: LocalDate): String = date.format(java.time.format.DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()))
}
