# DayBuddy from your phone only

This bundle contains both the native Android project and a web app.

## Quickest route: web app
1. Sign in or create a GitHub account in your phone browser.
2. Create a new public repository named `daybuddy`.
3. Upload the contents of this project into the repository (including the `web` folder and `.github` folder). Keep the folder structure intact. GitHub's web upload can be fiddly on mobile; use the browser's Desktop site option if needed.
4. Open repository Settings → Pages and set the source to **GitHub Actions**.
5. Open the Actions tab and run **Deploy DayBuddy web app** if it did not run automatically. Wait for the green check, then open the Pages URL shown in the workflow run.
6. In Chrome, open that URL, tap ⋮, then **Add to Home screen** or **Install app**.

The web app stores custom dates in that browser on that phone. Browser notifications are best effort and cannot promise an exact daily notification when the browser is closed.

## Build the actual Android APK online
1. Upload the project contents to the same GitHub repository, preserving `.github/workflows/build-apk.yml`.
2. Open the repository's **Actions** tab, select **Build DayBuddy APK**, tap **Run workflow**, and wait for a green check.
3. Open that successful workflow run, scroll to **Artifacts**, and download `DayBuddy-debug-APK`.
4. Extract the downloaded artifact ZIP on your phone. Tap `app-debug.apk` to install. If Android asks, allow your browser or file manager to install unknown apps.
5. Open DayBuddy and allow notification permission.

The APK is a debug build for personal testing, not a Play Store release. Do not share GitHub credentials or private access tokens. GitHub's mobile UI changes over time, and uploading folders from Android can be awkward; if upload fails, use GitHub's web Desktop site mode.
