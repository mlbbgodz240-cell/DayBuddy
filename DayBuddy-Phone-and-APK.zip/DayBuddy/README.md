# DayBuddy ♡

This project includes **two versions**:

- `app/`: native Android app with Android notifications and locally stored custom dates.
- `web/`: cute installable web app that can be pinned to your Android home screen.

## Phone-only setup
Read `PHONE-ONLY-GUIDE.md`. The included GitHub Actions workflows can build a debug APK in the cloud and deploy the web app to GitHub Pages. No Android Studio on your phone is needed, but you do need a GitHub account and must upload the project with its folder structure preserved.

## Notification limitations
The native Android app uses Android alarms and notifications, subject to Android permission and battery settings. The web app checks special dates when opened and browser notifications are best effort; it cannot guarantee daily background notifications while closed.

## Calendar note
The built-in calendar is a small curated list, not an exhaustive worldwide calendar. Add local celebrations or any personal date you want.
